# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/baihong/baihong_ws/src/F1_10_car/baihong_zeng_reactive/include".split(';') if "/home/baihong/baihong_ws/src/F1_10_car/baihong_zeng_reactive/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lbaihong_zeng_reactive".split(';') if "-lbaihong_zeng_reactive" != "" else []
PROJECT_NAME = "baihong_zeng_reactive"
PROJECT_SPACE_DIR = "/home/baihong/baihong_ws/src/F1_10_car/baihong_zeng_reactive/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
