# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/baihong/baihong_ws/src/F1_10_car/rrt/include".split(';') if "/home/baihong/baihong_ws/src/F1_10_car/rrt/include" != "" else []
PROJECT_CATKIN_DEPENDS = "ackermann_msgs;geometry_msgs;roscpp;rospy;sensor_msgs;std_msgs;tf".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrrt".split(';') if "-lrrt" != "" else []
PROJECT_NAME = "rrt"
PROJECT_SPACE_DIR = "/home/baihong/baihong_ws/src/F1_10_car/rrt/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
