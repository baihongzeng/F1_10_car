# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/usr/local/include".split(';') if "/usr/local/include" != "" else []
PROJECT_CATKIN_DEPENDS = "ackermann_msgs;geometry_msgs;roscpp;rospy;sensor_msgs;std_msgs;tf".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrrt".split(';') if "-lrrt" != "" else []
PROJECT_NAME = "rrt"
PROJECT_SPACE_DIR = "/usr/local"
PROJECT_VERSION = "0.0.0"
