The video is available in this link: https://youtu.be/rLTdtl725sE
or search: Upenn ESE680-007 Autonomous Racing lab 5 scan_matching_localization in youtube.
